import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { R as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { t as Slot } from "../_libs/radix-ui__react-slot.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/button-CE_D-Bin.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var LANGS = [
	"az",
	"en",
	"ar",
	"ru"
];
var LANG_META = {
	az: {
		label: "AZ",
		native: "Azərbaycan"
	},
	en: {
		label: "EN",
		native: "English"
	},
	ar: {
		label: "AR",
		native: "العربية"
	},
	ru: {
		label: "RU",
		native: "Русский"
	}
};
var translations = {
	az: {
		nav_apps: "Tətbiqlər",
		nav_craft: "Sənətkarlıq",
		nav_about: "Haqqımızda",
		btn_discover: "Kəşf et",
		btn_back: "Geri",
		eyebrow_studio: "MOBİL STUDİYA",
		hero_line1: "İdeyalar",
		hero_accent: "gözəlləşir.",
		hero_desc: "Faydalı mobil tətbiqləri sadə istifadə, güclü funksiyalar və premium dizaynla hazırlayırıq — ilk toxunuşdan hiss olunan sənətkarlıqla.",
		btn_explore_apps: "Tətbiqləri kəşf et",
		btn_about_nibras: "Nibras Code haqqında",
		stat_simple: "Sadə istifadə",
		stat_premium: "Premium interfeys",
		stat_useful: "Faydalı ideyalar",
		card_status: "HAZIRLANIR",
		card_apps: "TƏTBİQLƏR",
		scroll_text: "AŞAĞI SÜRÜŞDÜRÜN",
		live_label: "Studio canlıdır",
		apps_eyebrow: "SEÇİLMİŞ İŞLƏR",
		apps_h2_lead: "Bizim",
		apps_h2_em: "tətbiqlərimiz.",
		apps_desc: "Nibras Code tərəfindən hazırlanan mobil tətbiqlər — sakit, dəqiq, istifadəyə hazır.",
		featured_label: "TƏTBİQ · 01",
		featured_title: "Nibras Arabic",
		featured_desc: "Ərəb dili öyrənməsini daha praktik və rahat edən müasir mobil tətbiq. Hərflər, məşq və gündəlik ritm — bir sakit interfeysdə.",
		featured_explore: "Tətbiqi kəşf et",
		tag_lang: "Ərəb dili",
		tag_mobile: "Mobil",
		tag_year: "2026",
		next_label: "NÖVBƏTİ LAYİHƏ",
		next_desc: "Yeni tətbiq yoldadır.",
		next_hint: "Tezliklə",
		craft_eyebrow: "NECƏ İŞLƏYİRİK",
		craft_h2_lead: "Sakit interfeys.",
		craft_h2_em: "Güclü nəticə.",
		craft_desc: "Hər tətbiq eyni intizamla qurulur — ehtiyacdan forma, formadan hiss.",
		craft1_t: "Dinlə",
		craft1_d: "Xüsusiyyət siyahısından yox, istifadəçinin real ehtiyacından başlayırıq.",
		craft2_t: "Formalaşdır",
		craft2_d: "İnterfeys sakit qalır ki, iş özü görünsün. Hər ekran bir vəzifə daşıyır.",
		craft3_t: "Cilala",
		craft3_d: "Hərəkət, tipografiya və toxunuş hissi qaçılmaz olana qədər işlənir.",
		about_label_word: "HAQQIMIZDA",
		about_eyebrow: "BİZ KİMİK",
		about_h2_lead: "Texnologiya",
		about_h2_em: "sadə olmalıdır.",
		about_desc: "Nibras — işıq, yol göstərən. Nibras Code istifadəçinin ehtiyacına fokuslanan, təmiz interfeysli və müasir mobil tətbiqlər yaratmaq üçün qurulmuş bir studiyadır.",
		about_quote: "İlk toxunuş yetərincə aydın olmalıdır.",
		about_design: "DİZAYN",
		about_dev: "İNKİŞAF",
		about_exp: "TƏCRÜBƏ",
		about_design_d: "Tipografiya, ritm və boşluq. Hər piksel bir səbəbə xidmət edir.",
		about_dev_d: "Sürətli, sabit, native hiss. Gözəl olan həm də işləməlidir.",
		about_exp_d: "Öyrənmə əyrisi yox, dərhal anlaşılan jestlər və axın.",
		cta_kicker: "NÖVBƏTİ İŞIQ",
		cta_h2: "Yeni bir şey yoldadır.",
		cta_desc: "Nibras Code tətbiqləri bir-bir, diqqətlə çıxır. Birincisi artıq parlır.",
		cta_btn: "Seçilmiş işə bax",
		footer_tag: "Mobil Tətbiqlər",
		app_kicker: "TƏTBİQ · 01",
		app_desc: "Ərəb dili öyrənməsini daha praktik, rahat və müasir edən mobil tətbiq. Hərflər, qısa məşqlər və gündəlik ritm — diqqəti dağıtmayan premium interfeysdə.",
		app_back: "Tətbiqlərə qayıt",
		app_feat1_t: "Əlifba",
		app_feat1_d: "Hərfləri aydın forma və səslə öyrən — tələsik yox, dəqiq.",
		app_feat2_t: "Gündəlik məşq",
		app_feat2_d: "Qısa sessiyalar. Real irəliləyiş. Ertəsi günə qalan ritm.",
		app_feat3_t: "Sakit UI",
		app_feat3_d: "Premium, boşluqlu interfeys. Reklam yox, səs-küy yox.",
		app_feat4_t: "Praktik dil",
		app_feat4_d: "Nəzəriyyə yox — gündəlik həyatda işləyən ifadələr.",
		app_status: "Tezliklə mağazalarda",
		app_status_d: "Nibras Arabic hazırlanır. Tam xüsusiyyətlər növbəti mərhələdə.",
		app_lesson: "Bugünkü hərf",
		app_next: "Növbəti",
		menu_open: "Menyu",
		menu_close: "Bağla",
		lang_label: "Dil"
	},
	en: {
		nav_apps: "Apps",
		nav_craft: "Craft",
		nav_about: "About",
		btn_discover: "Discover",
		btn_back: "Back",
		eyebrow_studio: "MOBILE STUDIO",
		hero_line1: "Ideas made",
		hero_accent: "beautiful.",
		hero_desc: "We build useful mobile apps with simple usability, powerful features, and premium design — craft you can feel on the first tap.",
		btn_explore_apps: "Explore apps",
		btn_about_nibras: "About Nibras Code",
		stat_simple: "Simple to use",
		stat_premium: "Premium UI",
		stat_useful: "Useful ideas",
		card_status: "BUILDING",
		card_apps: "APPS",
		scroll_text: "SCROLL TO EXPLORE",
		live_label: "Studio live",
		apps_eyebrow: "SELECTED WORK",
		apps_h2_lead: "Our",
		apps_h2_em: "applications.",
		apps_desc: "Mobile apps built by Nibras Code — quiet, precise, ready to use.",
		featured_label: "APPLICATION · 01",
		featured_title: "Nibras Arabic",
		featured_desc: "A modern mobile app that makes learning Arabic more practical and convenient. Letters, practice, and a daily rhythm — in one quiet interface.",
		featured_explore: "Explore app",
		tag_lang: "Arabic",
		tag_mobile: "Mobile",
		tag_year: "2026",
		next_label: "NEXT PROJECT",
		next_desc: "A new app is on the way.",
		next_hint: "Soon",
		craft_eyebrow: "HOW WE WORK",
		craft_h2_lead: "Quiet interface.",
		craft_h2_em: "Loud result.",
		craft_desc: "Every app follows the same discipline — from a real need, to form, to feel.",
		craft1_t: "Listen",
		craft1_d: "We start from the user’s actual need, not a feature list.",
		craft2_t: "Shape",
		craft2_d: "The interface stays quiet so the work can be seen. One job per screen.",
		craft3_t: "Polish",
		craft3_d: "Motion, type, and tap-feel — until it feels inevitable.",
		about_label_word: "ABOUT",
		about_eyebrow: "WHO WE ARE",
		about_h2_lead: "Technology should feel",
		about_h2_em: "simple.",
		about_desc: "Nibras means lantern — a light for the path. Nibras Code is an app studio focused on user needs, built to create modern mobile apps with a clean interface.",
		about_quote: "The first tap should already feel clear.",
		about_design: "DESIGN",
		about_dev: "DEVELOPMENT",
		about_exp: "EXPERIENCE",
		about_design_d: "Type, rhythm, and space. Every pixel serves a reason.",
		about_dev_d: "Fast, stable, native-feeling. Beauty has to work.",
		about_exp_d: "No learning curve — gestures and flow that make sense immediately.",
		cta_kicker: "THE NEXT LIGHT",
		cta_h2: "Something new is on the way.",
		cta_desc: "Nibras Code ships apps one at a time, with care. The first one is already glowing.",
		cta_btn: "See selected work",
		footer_tag: "Mobile Applications",
		app_kicker: "APPLICATION · 01",
		app_desc: "A modern mobile app that makes learning Arabic more practical, convenient, and enjoyable. Letters, short drills, and a daily rhythm — in a premium interface that stays out of the way.",
		app_back: "Back to apps",
		app_feat1_t: "Alphabet",
		app_feat1_d: "Learn letters with clear forms and sound — unhurried, precise.",
		app_feat2_t: "Daily practice",
		app_feat2_d: "Short sessions. Real progress. A rhythm that returns tomorrow.",
		app_feat3_t: "Quiet UI",
		app_feat3_d: "Premium, spacious interface. No ads, no noise.",
		app_feat4_t: "Practical language",
		app_feat4_d: "Not theory — phrases that work in everyday life.",
		app_status: "Coming to stores",
		app_status_d: "Nibras Arabic is in the making. Full features land in the next phase.",
		app_lesson: "Today’s letter",
		app_next: "Next",
		menu_open: "Menu",
		menu_close: "Close",
		lang_label: "Language"
	},
	ar: {
		nav_apps: "التطبيقات",
		nav_craft: "الحرفة",
		nav_about: "من نحن",
		btn_discover: "استكشف",
		btn_back: "رجوع",
		eyebrow_studio: "استوديو الجوال",
		hero_line1: "الأفكار",
		hero_accent: "تصبح جميلة.",
		hero_desc: "نصمّم تطبيقات جوال مفيدة تجمع بين سهولة الاستخدام والميزات القوية والتصميم الفاخر — حرفة تُحس من أول لمسة.",
		btn_explore_apps: "استكشف التطبيقات",
		btn_about_nibras: "عن Nibras Code",
		stat_simple: "سهل الاستخدام",
		stat_premium: "واجهة فاخرة",
		stat_useful: "أفكار مفيدة",
		card_status: "قيد الإنشاء",
		card_apps: "تطبيقات",
		scroll_text: "مرّر للأسفل",
		live_label: "الاستوديو نشط",
		apps_eyebrow: "أعمال مختارة",
		apps_h2_lead: "هذه",
		apps_h2_em: "تطبيقاتنا.",
		apps_desc: "تطبيقات جوال من تطوير Nibras Code — هادئة، دقيقة، جاهزة للاستخدام.",
		featured_label: "تطبيق · 01",
		featured_title: "Nibras Arabic",
		featured_desc: "تطبيق جوال عصري يجعل تعلّم اللغة العربية أكثر عملية وسهولة. الحروف، التمرين، وإيقاع يومي — في واجهة واحدة هادئة.",
		featured_explore: "استكشف التطبيق",
		tag_lang: "العربية",
		tag_mobile: "جوال",
		tag_year: "2026",
		next_label: "المشروع القادم",
		next_desc: "تطبيق جديد قيد التطوير.",
		next_hint: "قريبًا",
		craft_eyebrow: "كيف نعمل",
		craft_h2_lead: "واجهة هادئة.",
		craft_h2_em: "أثر واضح.",
		craft_desc: "كل تطبيق يُبنى بنفس الانضباط — من حاجة حقيقية، إلى شكل، إلى إحساس.",
		craft1_t: "نصغي",
		craft1_d: "نبدأ من حاجة المستخدم الحقيقية، لا من قائمة ميزات.",
		craft2_t: "نُشكّل",
		craft2_d: "تبقى الواجهة هادئة كي يظهر العمل. مهمة واحدة لكل شاشة.",
		craft3_t: "نُصقِل",
		craft3_d: "الحركة والخط وملمس اللمس — حتى يصير الأمر حتميًا.",
		about_label_word: "عن",
		about_eyebrow: "من نحن",
		about_h2_lead: "التقنية يجب أن",
		about_h2_em: "تكون بسيطة.",
		about_desc: "نبراس تعني السراج — نورًا للطريق. Nibras Code استوديو تطبيقات يركّز على احتياجات المستخدم لإنشاء تطبيقات جوال عصرية بواجهة نظيفة.",
		about_quote: "اللمسة الأولى يجب أن تكون واضحة.",
		about_design: "التصميم",
		about_dev: "التطوير",
		about_exp: "التجربة",
		about_design_d: "الخط والإيقاع والفراغ. كل بكسل له سبب.",
		about_dev_d: "سريع، ثابت، بإحساس أصلي. الجمال يجب أن يعمل.",
		about_exp_d: "بلا منحنى تعلّم — إيماءات وتدفّق يُفهم فورًا.",
		cta_kicker: "النور التالي",
		cta_h2: "شيء جديد في الطريق.",
		cta_desc: "Nibras Code يُصدر التطبيقات واحدًا واحدًا، بعناية. الأول يضيء الآن.",
		cta_btn: "شاهد العمل المختار",
		footer_tag: "تطبيقات الجوال",
		app_kicker: "تطبيق · 01",
		app_desc: "تطبيق جوال عصري يجعل تعلّم اللغة العربية أكثر عملية وسهولة ومتعة. الحروف، تمارين قصيرة، وإيقاع يومي — في واجهة فاخرة لا تزاحم الانتباه.",
		app_back: "العودة إلى التطبيقات",
		app_feat1_t: "الألفباء",
		app_feat1_d: "تعلّم الحروف بأشكال واضحة وصوت — بلا عجلة، بدقّة.",
		app_feat2_t: "تمرين يومي",
		app_feat2_d: "جلسات قصيرة. تقدّم حقيقي. إيقاع يعود غدًا.",
		app_feat3_t: "واجهة هادئة",
		app_feat3_d: "واجهة فاخرة ومتسعة. بلا إعلانات، بلا ضجيج.",
		app_feat4_t: "لغة عملية",
		app_feat4_d: "ليست نظرية — عبارات تعمل في الحياة اليومية.",
		app_status: "قريبًا في المتاجر",
		app_status_d: "Nibras Arabic قيد الإعداد. الميزات الكاملة في المرحلة القادمة.",
		app_lesson: "حرف اليوم",
		app_next: "التالي",
		menu_open: "القائمة",
		menu_close: "إغلاق",
		lang_label: "اللغة"
	},
	ru: {
		nav_apps: "Приложения",
		nav_craft: "Ремесло",
		nav_about: "О нас",
		btn_discover: "Смотреть",
		btn_back: "Назад",
		eyebrow_studio: "МОБИЛЬНАЯ СТУДИЯ",
		hero_line1: "Идеи",
		hero_accent: "становятся красивыми.",
		hero_desc: "Мы создаём полезные мобильные приложения с простым интерфейсом, мощными функциями и премиальным дизайном — ремесло, которое чувствуется с первого касания.",
		btn_explore_apps: "Смотреть приложения",
		btn_about_nibras: "О Nibras Code",
		stat_simple: "Простота использования",
		stat_premium: "Премиум-интерфейс",
		stat_useful: "Полезные идеи",
		card_status: "СОЗДАЁМ",
		card_apps: "ПРИЛОЖЕНИЯ",
		scroll_text: "ЛИСТАЙТЕ ВНИЗ",
		live_label: "Студия онлайн",
		apps_eyebrow: "ИЗБРАННЫЕ РАБОТЫ",
		apps_h2_lead: "Наши",
		apps_h2_em: "приложения.",
		apps_desc: "Мобильные приложения от Nibras Code — спокойные, точные, готовые к использованию.",
		featured_label: "ПРИЛОЖЕНИЕ · 01",
		featured_title: "Nibras Arabic",
		featured_desc: "Современное мобильное приложение, которое делает изучение арабского практичнее и удобнее. Буквы, практика и дневной ритм — в одном тихом интерфейсе.",
		featured_explore: "Смотреть приложение",
		tag_lang: "Арабский",
		tag_mobile: "Мобильное",
		tag_year: "2026",
		next_label: "СЛЕДУЮЩИЙ ПРОЕКТ",
		next_desc: "Новое приложение уже на подходе.",
		next_hint: "Скоро",
		craft_eyebrow: "КАК МЫ РАБОТАЕМ",
		craft_h2_lead: "Тихий интерфейс.",
		craft_h2_em: "Ясный результат.",
		craft_desc: "Каждое приложение собирается с одной дисциплиной — от потребности к форме и ощущению.",
		craft1_t: "Слушаем",
		craft1_d: "Начинаем с реальной потребности пользователя, а не со списка функций.",
		craft2_t: "Формируем",
		craft2_d: "Интерфейс остаётся тихим, чтобы была видна работа. Один экран — одна задача.",
		craft3_t: "Шлифуем",
		craft3_d: "Движение, шрифт и ощущение касания — пока не станет неизбежным.",
		about_label_word: "О",
		about_eyebrow: "КТО МЫ",
		about_h2_lead: "Технологии должны",
		about_h2_em: "быть простыми.",
		about_desc: "Нибрас — светильник, свет на пути. Nibras Code — студия приложений, ориентированная на потребности пользователя и создающая современные мобильные приложения с чистым интерфейсом.",
		about_quote: "Первое касание уже должно быть ясным.",
		about_design: "ДИЗАЙН",
		about_dev: "РАЗРАБОТКА",
		about_exp: "ОПЫТ",
		about_design_d: "Шрифт, ритм и воздух. Каждый пиксель служит причине.",
		about_dev_d: "Быстро, стабильно, с нативным ощущением. Красота должна работать.",
		about_exp_d: "Без кривой обучения — жесты и поток, которые понятны сразу.",
		cta_kicker: "СЛЕДУЮЩИЙ СВЕТ",
		cta_h2: "Что-то новое уже в пути.",
		cta_desc: "Nibras Code выпускает приложения по одному, с заботой. Первое уже светится.",
		cta_btn: "Смотреть избранное",
		footer_tag: "Мобильные приложения",
		app_kicker: "ПРИЛОЖЕНИЕ · 01",
		app_desc: "Современное мобильное приложение, которое делает изучение арабского практичнее, удобнее и увлекательнее. Буквы, короткие упражнения и дневной ритм — в премиальном интерфейсе, который не мешает.",
		app_back: "Вернуться к приложениям",
		app_feat1_t: "Алфавит",
		app_feat1_d: "Учите буквы с ясной формой и звуком — без спешки, точно.",
		app_feat2_t: "Ежедневная практика",
		app_feat2_d: "Короткие сессии. Реальный прогресс. Ритм, который возвращается завтра.",
		app_feat3_t: "Тихий UI",
		app_feat3_d: "Премиальный, просторный интерфейс. Без рекламы и шума.",
		app_feat4_t: "Практичный язык",
		app_feat4_d: "Не теория — фразы, которые работают в повседневной жизни.",
		app_status: "Скоро в магазинах",
		app_status_d: "Nibras Arabic в работе. Полный набор функций — на следующем этапе.",
		app_lesson: "Буква дня",
		app_next: "Дальше",
		menu_open: "Меню",
		menu_close: "Закрыть",
		lang_label: "Язык"
	}
};
var MARQUEE = {
	az: [
		"DİZAYN",
		"İNKİŞAF",
		"MOBİL",
		"ƏRƏB DİLİ",
		"PREMIUM UI",
		"SADƏLİK",
		"SƏNƏTKARLIQ"
	],
	en: [
		"DESIGN",
		"DEVELOPMENT",
		"MOBILE",
		"ARABIC",
		"PREMIUM UI",
		"SIMPLICITY",
		"CRAFT"
	],
	ar: [
		"تصميم",
		"تطوير",
		"جوال",
		"العربية",
		"واجهة فاخرة",
		"بساطة",
		"حرفة"
	],
	ru: [
		"ДИЗАЙН",
		"РАЗРАБОТКА",
		"МОБИЛЬНОЕ",
		"АРАБСКИЙ",
		"PREMIUM UI",
		"ПРОСТОТА",
		"РЕМЕСЛО"
	]
};
var STORAGE_KEY = "nibras_lang";
var I18nContext = (0, import_react.createContext)(null);
function isLang(value) {
	return !!value && LANGS.includes(value);
}
function applyDocumentLang(lang) {
	const root = document.documentElement;
	root.lang = lang;
	root.dir = lang === "ar" ? "rtl" : "ltr";
}
function I18nProvider({ children }) {
	const [lang, setLangState] = (0, import_react.useState)("az");
	(0, import_react.useEffect)(() => {
		try {
			const stored = localStorage.getItem(STORAGE_KEY);
			if (isLang(stored)) {
				setLangState(stored);
				applyDocumentLang(stored);
				return;
			}
		} catch {}
		applyDocumentLang("az");
	}, []);
	const setLang = (0, import_react.useCallback)((next) => {
		setLangState(next);
		applyDocumentLang(next);
		try {
			localStorage.setItem(STORAGE_KEY, next);
		} catch {}
	}, []);
	const value = (0, import_react.useMemo)(() => {
		const dict = translations[lang];
		return {
			lang,
			dir: lang === "ar" ? "rtl" : "ltr",
			setLang,
			t: (key) => dict[key]
		};
	}, [lang, setLang]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(I18nContext.Provider, {
		value,
		children
	});
}
function useI18n() {
	const ctx = (0, import_react.useContext)(I18nContext);
	if (!ctx) throw new Error("useI18n must be used within I18nProvider");
	return ctx;
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 font-sans font-semibold tracking-wider uppercase transition-[transform,background-color,color,box-shadow,border-color,opacity] duration-150 ease-out active:not-disabled:scale-[0.96] disabled:pointer-events-none disabled:opacity-50", {
	variants: {
		variant: {
			primary: "bg-fg text-ink shadow-[0_12px_40px_rgb(109_132_255_/_0.22)] hover:bg-white",
			ghost: "border border-line-strong bg-white/4 text-fg hover:border-line-hot hover:bg-white/7",
			nav: "border border-line bg-white/4 text-fg hover:border-line-hot"
		},
		size: {
			default: "h-11 rounded-full px-5 text-2xs",
			sm: "h-10 rounded-full px-4 text-2xs",
			lg: "h-12 rounded-full px-6 text-2xs"
		}
	},
	defaultVariants: {
		variant: "primary",
		size: "default"
	}
});
function Button({ className, variant, size, asChild = false, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
}
//#endregion
export { MARQUEE as a, LANG_META as i, I18nProvider as n, cn as o, LANGS as r, useI18n as s, Button as t };

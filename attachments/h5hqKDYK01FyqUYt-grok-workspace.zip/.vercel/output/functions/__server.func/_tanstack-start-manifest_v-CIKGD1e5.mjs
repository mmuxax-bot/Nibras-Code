//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CIKGD1e5.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/", "/apps/nibras-arabic"],
		preloads: ["/assets/index-DPR35K9N.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DPR35K9N.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-jHdaX6Ao.js", "/assets/reveal-XUtRbSDS.js"]
	},
	"/apps/nibras-arabic": {
		filePath: "/workspace/src/routes/apps/nibras-arabic.tsx",
		children: void 0,
		preloads: ["/assets/nibras-arabic-CM1eVBM8.js", "/assets/reveal-XUtRbSDS.js"]
	}
} });
//#endregion
export { tsrStartManifest };

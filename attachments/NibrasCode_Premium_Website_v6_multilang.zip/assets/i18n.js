(function () {
  var translations = {
    az: {
      nav_apps: "Tətbiqlər",
      nav_about: "Haqqımızda",
      btn_discover: "Kəşf et",
      btn_back: "Geri",
      eyebrow_studio: "MOBİL STUDİYA",
      hero_h1: "İdeyalar<br><strong>gözəlləşir.</strong>",
      hero_desc: "Faydalı mobil tətbiqləri sadə istifadə, güclü funksiyalar və premium dizaynla hazırlayırıq.",
      btn_explore_apps: "Tətbiqləri kəşf et",
      btn_about_nibras: "Nibras Code haqqında",
      stat_simple: "Sadə istifadə",
      stat_premium: "Premium interfeys",
      stat_useful: "Faydalı ideyalar",
      card_status: "HAZIRLANIR",
      card_apps: "TƏTBİQLƏR",
      scroll_text: "AŞAĞI SÜRÜŞDÜRÜN",
      apps_eyebrow: "SEÇİLMİŞ İŞLƏR",
      apps_h2: "Bizim <em>tətbiqlərimiz.</em>",
      apps_desc: "Nibras Code tərəfindən hazırlanan mobil tətbiqlər.",
      featured_label: "TƏTBİQ · 01",
      featured_desc: "Ərəb dili öyrənməsini daha praktik və rahat edən müasir mobil tətbiq.",
      featured_explore: "Tətbiqi kəşf et",
      next_label: "NÖVBƏTİ LAYİHƏ",
      next_desc: "Yeni tətbiq yoldadır.",
      about_label_word: "HAQQIMIZDA",
      about_eyebrow: "BİZ KİMİK",
      about_h2: "Texnologiya<br><em>sadə olmalıdır.</em>",
      about_desc: "Nibras Code istifadəçinin ehtiyacına fokuslanan, təmiz interfeysli və müasir mobil tətbiqlər yaratmaq üçün qurulmuş bir tətbiq studiyasıdır.",
      about_design: "DİZAYN",
      about_dev: "İNKİŞAF",
      about_exp: "TƏCRÜBƏ",
      footer_tag: "Mobil Tətbiqlər",
      app_desc: "Ərəb dili öyrənməsini daha praktik, rahat və müasir edən mobil tətbiq. Bu səhifə növbəti mərhələdə tətbiqin bütün xüsusiyyətləri ilə genişləndiriləcək.",
      app_back: "Tətbiqlərə qayıt"
    },
    en: {
      nav_apps: "Apps",
      nav_about: "About",
      btn_discover: "Discover",
      btn_back: "Back",
      eyebrow_studio: "MOBILE STUDIO",
      hero_h1: "Ideas made<br><strong>beautiful.</strong>",
      hero_desc: "We build useful mobile apps with simple usability, powerful features, and premium design.",
      btn_explore_apps: "Explore apps",
      btn_about_nibras: "About Nibras Code",
      stat_simple: "Simple to use",
      stat_premium: "Premium UI",
      stat_useful: "Useful ideas",
      card_status: "BUILDING",
      card_apps: "APPS",
      scroll_text: "SCROLL TO EXPLORE",
      apps_eyebrow: "SELECTED WORK",
      apps_h2: "Our <em>applications.</em>",
      apps_desc: "Mobile apps built by Nibras Code.",
      featured_label: "APPLICATION · 01",
      featured_desc: "A modern mobile app that makes learning Arabic more practical and convenient.",
      featured_explore: "Explore app",
      next_label: "NEXT PROJECT",
      next_desc: "A new app is on the way.",
      about_label_word: "ABOUT",
      about_eyebrow: "WHO WE ARE",
      about_h2: "Technology should feel<br><em>simple.</em>",
      about_desc: "Nibras Code is an app studio focused on user needs, built to create modern mobile apps with a clean interface.",
      about_design: "DESIGN",
      about_dev: "DEVELOPMENT",
      about_exp: "EXPERIENCE",
      footer_tag: "Mobile Applications",
      app_desc: "A modern mobile app that makes learning Arabic more practical, convenient, and enjoyable. This page will be expanded in the next phase with the app's full features.",
      app_back: "Back to apps"
    },
    ar: {
      nav_apps: "التطبيقات",
      nav_about: "من نحن",
      btn_discover: "استكشف",
      btn_back: "رجوع",
      eyebrow_studio: "استوديو الجوال",
      hero_h1: "الأفكار<br><strong>تصبح جميلة.</strong>",
      hero_desc: "نصمّم تطبيقات جوال مفيدة تجمع بين سهولة الاستخدام والميزات القوية والتصميم الفاخر.",
      btn_explore_apps: "استكشف التطبيقات",
      btn_about_nibras: "عن Nibras Code",
      stat_simple: "سهل الاستخدام",
      stat_premium: "واجهة فاخرة",
      stat_useful: "أفكار مفيدة",
      card_status: "قيد الإنشاء",
      card_apps: "تطبيقات",
      scroll_text: "مرّر للأسفل للاستكشاف",
      apps_eyebrow: "أعمال مختارة",
      apps_h2: "<em>تطبيقاتنا.</em>",
      apps_desc: "تطبيقات جوال من تطوير Nibras Code.",
      featured_label: "تطبيق · 01",
      featured_desc: "تطبيق جوال عصري يجعل تعلّم اللغة العربية أكثر عملية وسهولة.",
      featured_explore: "استكشف التطبيق",
      next_label: "المشروع القادم",
      next_desc: "تطبيق جديد قيد التطوير.",
      about_label_word: "عن",
      about_eyebrow: "من نحن",
      about_h2: "التقنية يجب أن<br><em>تكون بسيطة.</em>",
      about_desc: "Nibras Code استوديو تطبيقات يركّز على احتياجات المستخدم لإنشاء تطبيقات جوال عصرية بواجهة نظيفة.",
      about_design: "التصميم",
      about_dev: "التطوير",
      about_exp: "التجربة",
      footer_tag: "تطبيقات الجوال",
      app_desc: "تطبيق جوال عصري يجعل تعلّم اللغة العربية أكثر عملية وسهولة ومتعة. سيتم توسيع هذه الصفحة في المرحلة القادمة بجميع ميزات التطبيق.",
      app_back: "العودة إلى التطبيقات"
    },
    ru: {
      nav_apps: "Приложения",
      nav_about: "О нас",
      btn_discover: "Смотреть",
      btn_back: "Назад",
      eyebrow_studio: "МОБИЛЬНАЯ СТУДИЯ",
      hero_h1: "Идеи<br><strong>становятся красивыми.</strong>",
      hero_desc: "Мы создаём полезные мобильные приложения с простым интерфейсом, мощными функциями и премиальным дизайном.",
      btn_explore_apps: "Смотреть приложения",
      btn_about_nibras: "О Nibras Code",
      stat_simple: "Простота использования",
      stat_premium: "Премиум-интерфейс",
      stat_useful: "Полезные идеи",
      card_status: "СОЗДАЁМ",
      card_apps: "ПРИЛОЖЕНИЯ",
      scroll_text: "ЛИСТАЙТЕ ВНИЗ",
      apps_eyebrow: "ИЗБРАННЫЕ РАБОТЫ",
      apps_h2: "Наши <em>приложения.</em>",
      apps_desc: "Мобильные приложения от Nibras Code.",
      featured_label: "ПРИЛОЖЕНИЕ · 01",
      featured_desc: "Современное мобильное приложение, которое делает изучение арабского языка более практичным и удобным.",
      featured_explore: "Смотреть приложение",
      next_label: "СЛЕДУЮЩИЙ ПРОЕКТ",
      next_desc: "Новое приложение уже на подходе.",
      about_label_word: "О",
      about_eyebrow: "КТО МЫ",
      about_h2: "Технологии должны<br><em>быть простыми.</em>",
      about_desc: "Nibras Code — студия приложений, ориентированная на потребности пользователя и создающая современные мобильные приложения с чистым интерфейсом.",
      about_design: "ДИЗАЙН",
      about_dev: "РАЗРАБОТКА",
      about_exp: "ОПЫТ",
      footer_tag: "Мобильные приложения",
      app_desc: "Современное мобильное приложение, которое делает изучение арабского языка более практичным, удобным и увлекательным. Эта страница будет дополнена всеми функциями приложения на следующем этапе.",
      app_back: "Вернуться к приложениям"
    }
  };

  var STORAGE_KEY = "nibras_lang";

  function getStoredLang() {
    try {
      return localStorage.getItem(STORAGE_KEY);
    } catch (e) {
      return null;
    }
  }

  function storeLang(lang) {
    try {
      localStorage.setItem(STORAGE_KEY, lang);
    } catch (e) {}
  }

  function applyLanguage(lang) {
    if (!translations[lang]) lang = "az";
    var dict = translations[lang];

    document.documentElement.setAttribute("lang", lang);
    document.documentElement.setAttribute("dir", lang === "ar" ? "rtl" : "ltr");
    document.body.classList.toggle("is-rtl", lang === "ar");

    document.querySelectorAll("[data-i18n]").forEach(function (el) {
      var key = el.getAttribute("data-i18n");
      if (dict[key] !== undefined) el.textContent = dict[key];
    });

    document.querySelectorAll("[data-i18n-html]").forEach(function (el) {
      var key = el.getAttribute("data-i18n-html");
      if (dict[key] !== undefined) el.innerHTML = dict[key];
    });

    document.querySelectorAll(".lang-btn").forEach(function (btn) {
      var isActive = btn.getAttribute("data-lang") === lang;
      btn.classList.toggle("active", isActive);
      btn.setAttribute("aria-pressed", isActive ? "true" : "false");
    });

    storeLang(lang);
  }

  function init() {
    var lang = getStoredLang() || document.documentElement.getAttribute("data-default-lang") || "az";
    applyLanguage(lang);

    document.querySelectorAll(".lang-btn").forEach(function (btn) {
      btn.addEventListener("click", function () {
        applyLanguage(btn.getAttribute("data-lang"));
      });
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }

  window.NibrasI18n = { applyLanguage: applyLanguage };
})();
